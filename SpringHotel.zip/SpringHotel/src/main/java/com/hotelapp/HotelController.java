package com.hotelapp;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.hotelapp.exception.HotelNotFoundException;

@Controller
public class HotelController throws HotelNotFoundException {
	@RequestMapping("/")
	public String home() {
		System.out.println("Home Page...");
		return "index";
	}
	@GetMapping("/register")
	public String showForm(Model model) throws HotelNotFoundException  {
		User user = new User();
		model.addAttribute("user",user);
		List<String> roomsList = Arrays.asList("Non-AC","AC","Delux-AC");
		model.addAttribute("roomsList", roomsList);
		List<String> indoorList = Arrays.asList("Chess","Carom","Table-Tennis","Indoor Basket ball");
		model.addAttribute("indoorList", indoorList);
		List<String> outdoorList = Arrays.asList("Cricket","Football","Tennis","Badmitton");
		model.addAttribute("outdoorList", outdoorList);
		List<String> cuisineList = Arrays.asList("Indian","South-Indian","Italian","Chinise");
		model.addAttribute("cuisineList", cuisineList);
		
		return "register_form";
	}
	@PostMapping("/register")
	public String submitForm(@ModelAttribute("user") User user) {
		System.out.println(user);
		return "register_success";
	}
	

}
