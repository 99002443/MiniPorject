package com.hotelapp;

import java.util.Date;

public class User {
	private String name;
	private String city;
	private String state;
	private String gender;
	private String typerooms;
	private String indoorgames;
	private String outdoorgames;
	private String cuisine;
	private String transport;
	private String id,phoneno;
	private Date dob;
	private Integer age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTyperooms() {
		return typerooms;
	}
	public void setTyperooms(String typerooms) {
		this.typerooms = typerooms;
	}
	public String getIndoorgames() {
		return indoorgames;
	}
	public void setIndoorgames(String indoorgames) {
		this.indoorgames = indoorgames;
	}
	public String getOutdoorgames() {
		return outdoorgames;
	}
	public void setOutdoorgames(String outdoorgames) {
		this.outdoorgames = outdoorgames;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public String getTransport() {
		return transport;
	}
	public void setTransport(String transport) {
		this.transport = transport;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", city=" + city + ", state=" + state + ", gender=" + gender + ", typerooms="
				+ typerooms + ", indoorgames=" + indoorgames + ", outdoorgames=" + outdoorgames + ", cuisine=" + cuisine
				+ ", transport=" + transport + ", id=" + id + ", phoneno=" + phoneno + ", dob=" + dob + ", age=" + age
				+ "]";
	}
	
	
	
	

}
